# Design Document for FlavorFinder
## Introduction
FlavorFinder is a Flask-based web application designed to provide detailed profiles of various alcoholic beverages. It allows users to explore, interact, and comment on different beverage types.

## Architecture
- **Front-End**: HTML, CSS (Bootstrap), JavaScript.
- **Back-End**: Python Flask, SQLite database.
- **User Authentication**: Implemented using Flask session management and Werkzeug for password hashing.
- **Data Management**: SQL queries handle data retrieval and manipulation in SQLite.

## Key Design Decisions
- #### User Authentication
- Flask’s Session-Based Authentication, enabling secure management of user sessions and hashed password storage.
- #### Database Schema
- Our SQLite schema optimally stores user and liquor data, ensuring quick data retrieval and maintaining data integrity through relational structures.
- #### API Endpoints
- Developed to dynamically serve liquor data, these Flask endpoints ensure interactive and real-time user experiences, and are integral for feeding data to Chart.js for engaging visualizations.

## Dependencies and Technologies Used
Our project, FlavorFinder, relies on a suite of powerful technologies and libraries to deliver a robust web application experience.
- #### Core Technologies
- [**Flask**](https://flask.palletsprojects.com/en/3.0.x/): A Python-based web framework, selected for its simplicity and flexibility, which forms the backbone of our server and routing capabilities.
- [**SQLite**](https://www.sqlite.org/index.html): Our choice for a lightweight, yet powerful, database system. It's integrated seamlessly with Flask for efficient data storage and retrieval.
- [**Chart.js**](https://www.chartjs.org/docs/latest/): Utilized for creating dynamic and interactive charts, enhancing the visualization of beverage profiles.

- #### Supporting Libraries
- [**CS50 Library for Python**](https://cs50.readthedocs.io/libraries/cs50/python/): Streamlines interactions with SQLite databases, making database operations more efficient.
- [**Werkzeug**](https://werkzeug.palletsprojects.com/en/2.0.x/): Empowers our application with secure password handling and utility functions, bolstering user security.
- [**Flask-Session**](https://flask-session.readthedocs.io/en/latest/): Enhances user experience by providing server-side session management.
- [**Python Libraries**](https://docs.python.org/3/library/index.html): A set of versatile libraries providing a range of functionality from data handling to system operations.

## Implementation
FlavorFinder is composed of several key files that work together to create a seamless and interactive experience for the user. Below is an overview of these files and their roles:

##### `app.py`
This is the backbone of the Flask application, where all routes and logic for web pages are defined. It includes routes for rendering pages like whiskey, champagne, beer, wine, and comments. It also handles user authentication, form submissions, and database queries.

##### `helpers.py`
This file includes helper functions that `app.py` uses, It includes custom decorators like `login_required` to restrict access to certain routes and `apology` for error handling. It also contains functions for password hashing and verification.

##### `static` and `templates` Directories
- **`static`**: Contains all static content such as CSS and image files.
- **`templates`**: Holds all the HTML template files used by Flask's `render_template` function. These templates dynamically display data based on user interaction and database content.

## Challenges and Solutions
- **Dynamic Data Visualization**: Implementing Chart.js for real-time data representation was challenging. Solution involved AJAX calls to Flask routes returning JSON data.

## Future Improvements
- Enhanced user interaction with more dynamic content.
- Inclusion of AI api for personal customization.
- Introduction of a recommendation system based on user preferences.

