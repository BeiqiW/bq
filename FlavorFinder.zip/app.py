import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session, jsonify
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash
from helpers import apology, login_required
import datetime

# Configure application
app = Flask(__name__)
db = SQL("sqlite:///final.db")
comments = []

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 400)

        # Ensure password confirmation
        elif not request.form.get("confirmation"):
            return apology("must confirm password", 400)

        # Ensure password confirmation match
        elif request.form.get("password") != request.form.get("confirmation"):
            return apology("password must match", 400)

        # save username and password hash in variables
        username = request.form.get("username")
        hash = generate_password_hash(request.form.get("password"))

        # Query database to ensure username isn't already taken
        rows = db.execute(
            "SELECT * FROM users WHERE username = :username", username=username
        )
        if len(rows) != 0:
            return apology("username is already taken", 400)

        # insert username and hash into database
        db.execute(
            "INSERT INTO users (username, hash) VALUES (:username, :hash)",
            username=username,
            hash=hash,
        )

        # redirect to login page
        return redirect("/login")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("the password you entered is incorrect", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/change_password", methods=["GET", "POST"])
def change_password():
    if request.method == "POST":
        username = request.form.get("username")
        current_password = request.form.get("current_password")
        new_password = request.form.get("new_password")
        confirmation = request.form.get("confirmation")

        # Make sure all necessary form fields are submitted
        if not username or not current_password or not new_password or not confirmation:
            return apology("must provide all fields", 400)

        # Make sure the new password and confirm password match
        if new_password != confirmation:
            return apology("passwords do not match", 400)

        # find user in database
        rows = db.execute(
            "SELECT * FROM users WHERE username = :username", username=username
        )

        # Check if the username exists and if the current password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], current_password):
            return apology("invalid username and/or password", 400)

        # update new password
        new_hash = generate_password_hash(new_password)
        db.execute(
            "UPDATE users SET hash = :new_hash WHERE id = :user_id",
            new_hash=new_hash,
            user_id=rows[0]["id"],
        )

        flash("Password changed successfully!")
        return redirect("/login")
    else:
        return render_template("change_password.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()
    # Redirect user to login form
    return redirect("/")


@app.route("/")
def index():
    # Render the main index page
    return render_template("index.html")


@app.route("/whiskey")
@login_required
def whiskey():
    # Query and display whiskey profiles
    whiskey_data = db.execute("SELECT * FROM whiskey_profiles")
    return render_template("whiskey.html")


@app.route("/champagne")
@login_required
def champagne():
    # Query and display champagne profiles
    champagne_data = db.execute("SELECT * FROM champagne_profiles")
    return render_template("champagne.html")

@app.route("/beer")
@login_required
def beer():
    # Query and display beer profiles
    beer_data = db.execute("SELECT * FROM beer_profiles")
    return render_template("beer.html")


@app.route("/wine")
@login_required
def wine():
    # Query and display wine profiles
    wine_data = db.execute("SELECT * FROM wine_profiles")
    return render_template("wine.html")

@app.route("/comment", methods=["GET", "POST"])
@login_required
def comment():
    if request.method == "POST":
        # get comment from form data
        comment_text = request.form.get("comment")
        user_id = session["user_id"]

        try:
            # get username
            user_info = db.execute("SELECT username FROM users WHERE id = ?", user_id)
            if not user_info:
                return redirect("/comment")

            current_username = user_info[0]["username"]

            # insert comment
            db.execute("INSERT INTO comments (username, comment, created_at) VALUES (?, ?, ?)",
                      current_username, comment_text, datetime.datetime.now())

        except Exception as e:
            # debug
            print(e)

        # get comments from the current
        comment_data = db.execute("SELECT * FROM comments ORDER BY created_at DESC")

        # redirect
        return render_template("comment.html", comments=comment_data)

    else:
        comment_data = db.execute("SELECT * FROM comments ORDER BY created_at DESC")
        return render_template("comment.html", comments=comment_data)


@app.route("/get-beer-data")
def get_beer_data():
    # Fetch beer data based on query parameter
    beer_type = request.args.get("type")
    if beer_type:
        query = "SELECT * FROM beer_profiles WHERE name = :name"
        data = db.execute(query, name=beer_type)
    else:
        query = "SELECT * FROM beer_profiles"
        data = db.execute(query)
    return jsonify(data)


@app.route("/get-wine-data")
def get_wine_data():
    # Fetch wine data based on query parameter
    wine_type = request.args.get("type")
    if wine_type:
        query = "SELECT * FROM wine_profiles WHERE name = :name"
        data = db.execute(query, name=wine_type)
    else:
        query = "SELECT * FROM wine_profiles"
        data = db.execute(query)
    return jsonify(data)


@app.route("/get-champagne-data")
def get_champagne_data():
    # Fetch champagne data based on query parameter
    champagne_type = request.args.get("type")
    if champagne_type:
        query = "SELECT * FROM champagne_profiles WHERE name = :name"
        data = db.execute(query, name=champagne_type)
    else:
        query = "SELECT * FROM champagne_profiles"
        data = db.execute(query)
    return jsonify(data)


@app.route("/get-whiskey-data")
def get_whiskey_data():
    # Fetch whiskey data based on query parameter
    whiskey_type = request.args.get("type")
    if whiskey_type:
        query = "SELECT * FROM whiskey_profiles WHERE name = :name"
        data = db.execute(query, name=whiskey_type)
    else:
        query = "SELECT * FROM whiskey_profiles"
        data = db.execute(query)
    return jsonify(data)


if __name__ == "__main__":
    app.run(debug=True)
