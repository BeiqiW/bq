# FlavorFinder
## _Discover Your Perfect Drink_

## CS50
>This project, FlavorFinder, was developed as our final project for CS50's Introduction to Computer Science course. Emphasizing web development skills, it integrates Python, Flask web framework, HTML, CSS, and JavaScript, showcasing a comprehensive understanding of these key technologies.

## Overview
#### What is FlavorFinder, and how can it benefit us?
FlavorFinder is a dynamic web application that revolutionizes the way users discover and explore alcoholic beverages. It categorizes drinks into four main groups: Whisky, Wine, Beer, and Champagne, and presents an extensive database of each, complete with details like ingredients and alcohol content. The application's standout feature is its interactive radar charts, which visually compare attributes such as sweetness and strength. This, combined with a user-driven review system, makes FlavorFinder an engaging and informative platform for both beverage enthusiasts and curious explorers alike.

## Features
#### User Authentication
FlavorFinder incorporates a user authentication system, ensuring secure and personalized user experiences, including registration with unique username validation and secure password hashing, alongside login, logout, and password change functionalities ensuring secure access and data protection.
#### Profile Exploration
The application offers detailed profiles of various alcoholic beverages, enhancing user exploration. Provides detailed information about different types of whiskey, wine, beer, and champagne. Users can search for specific beverage types or filter based on preferences like dryness, sweetness, or bitterness.
#### Interactive Charts
Interactive charts visually represent beverage characteristics, offering a dynamic user experience. Rada Charts displays attributes such as dryness, sweetness, acidity, and body of beverages. Charts update in real-time based on user interactions, letting users gain insights into different drinks' flavor profiles.

#### User Comments
A feature allowing community engagement and knowledge sharing among users. Registered users can post comments on beverage profiles to share opinions or recommendations. And users can view comments from the community, fostering a shared learning environment.


## Installation
    1.Open VS Code.Start terminal window, then execute cd by itself,It should shows:
    $
    2.Click inside of that terminal window and then execute
    wget https://github.com/BeiqiW/bq/blob/main/FlavorFinder.zip
    3.In order to download a ZIP called FlavorFinder.zip in your codespace,
    hit ENTER
    4.To create a folder called FlavorFinder now execute
    unzip FlavorFinder.zip
    5.No longer need the ZIP file, so you can execute
    rm FlavorFinder.zip, and respond with “y”.
    6.Now type
    cd FlavorFinder
    7.Your prompt should now resemble the below.
    FlavorFinder/ $
    8.If all was successful, you should execute
    ls
    and you should see the files and folders.

## Usage
### Running the Project
1. **Start the Flask Server**
    In your terminal, execute `flask run`.This starts the local server for the application.
2. **Access the Application**
    Open a web browser and navigate to the website provided in the terminal. This will load the home page of FlavorFinder.

### Interacting with the Application
1. **Navigating Beverage Profiles**
    Use the navigation bar to select different beverage categories such as Whiskey, Wine, Beer, or Champagne. Each category page presents detailed profiles and information specific to that beverage type.
2. **Using Interactive Charts**
    On each beverage profile page, find interactive charts displaying various characteristics like flavor, body, or sweetness. Click on different types to view detailed profiles.
3. **Posting and Viewing Comments**
  If logged in, you can post comments on beverage profiles to share your thoughts or experiences. Read comments from other users to gain different perspectives or recommendations.
4. **Managing User Account**
  Utilize user-specific features like changing passwords, logging out, or updating your profile through the account management options.

### Presentation
For the CS50 final project we make a video showning our project.
[FlavorFinder presentation](https://www.youtube.com/watch?v=jjdkDYBth3M)

## Contact
For any questiones, please contact
- Beiqi Wang(beiqiwang@gsd.harvard.edu).
- Qiao Li(qiao_li@gsd.harvard.edu).

## This is CS50! Thank you for everything!
